% ������ȡ��motif ����motif����
% ���룺motifԪ��
% ���������Ȩ������net
function net=net_motif(motif)
n=length(motif);
net=cell(n,1);
parfor i=1:n-1
    aa1=motif{i};
%     fprintf('%d �У���%d ��\n',i,n);
    hehe=disss(aa1,i,n,motif);
    net{i}=hehe;
end
net{n}=zeros(1,n);
     
%     for j=i+1:n
% %         fprintf('%d �У�%d ��\n',i,j);
%         aa2=motif{j};
%         ss=disss(aa1,aa2);
%         
%         net(i,j)=ss/4;
% %         net(j,i)=ss/4;
%     end
net=cell2mat(net);
net=net+net';
end


% 
function hehe=disss(aa1,i,n,motif)
hehe=zeros(1,n);
for j=i+1:n
    ss=0;
    aa2=motif{j};
    for k=1:2
        for v=1:2
            ss=ss+NW_sim(aa1{k},aa2{v});
        end
    end
    ss=ss/4;
    hehe(j)=ss;
end
end
                    


% ���о���
function sim=NW_sim(seq1,seq2)
[Score,Alignment] = nwalign(seq1,seq2,'Alphabet','NT','GapOpen',8,'ExtendGap',0.5);

Identity=length(find(Alignment(1,:)==Alignment(3,:)));
% distance=1-Identity/L; %#ok<NASGU> %%%% Uclust define

L=min(length(Alignment(1,:))-length(findstr(Alignment(1,:),'-')),length(Alignment(3,:))-length(findstr(Alignment(3,:),'-')));
sim=Identity/L; %%%% cdhit define
end
