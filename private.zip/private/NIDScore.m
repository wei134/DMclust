function NID=NIDScore(clusters,annos)
%Matlab code for computing Normalized Mutual Information (NMI) score
% Input: 
%       clusters : a cell array containing clustering results, each cell element
%                  is a cluster. The indices ([1..M]) of all elements
%                  belonging to that cluster are listed.
%       annos    : a M*1 array or M-cell array containing the true labels of each
%                  element. The labels can be strings or digits
%Output:
%       The NMI score

%   count number of elements
numsq=length(annos);
%   converts text annotations to digits
[uanno dumm idsanno]=unique(annos);
uqanno=[];
uqanno=unique(idsanno);

vol_c=[];entro_c=0;
for i=1:numel(uqanno)
    vol_c(i)=sum(idsanno==uqanno(i))/numsq;
    entro_c=entro_c+vol_c(i)*log(vol_c(i));
end

entro_g=0;
mui=0;

for i=1:numel(clusters)
    grp=clusters{i};
    cr=idsanno(grp);
    vol_g=numel(grp)/numsq;
    entro_g=entro_g+vol_g*log(vol_g);
    ucr=unique(cr);
    for xtr=1:length(ucr)
        crcount=sum(cr==ucr(xtr));
        ucid=find(uqanno==ucr(xtr));
        mui=mui+crcount/numsq*log(crcount/(numel(grp)*vol_c(ucid))); 
    end
end
NID=1+mui/max(entro_g,entro_c);
return